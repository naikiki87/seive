<template>
  <div class = "panel panel-default">
    <div class="panel-heading"> Panel heading without title </div>
    <div class="panel-body"> Panel Content </div>
  </div>
</template>

<script>
export default {
  name: 'Example',
  data() {
    return {
      msg : 'Basic panel example'
    }
  }
}
</script>
