<template>
  <div style="background : blue; height:400px; width : 400px; border : 1px solid;">dddd
  </div>
</template>

<script>
export default {
}

</script>

<style>
th, td {
  height : 25px;
  padding : 0px;
  border : 0.1px solid #d8d8d8;
  background : #fafafa

}
table {
  font-size : 14px;
  border : 1px solid;
}
</style>
