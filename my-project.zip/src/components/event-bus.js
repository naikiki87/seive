import Vue from "Vue";
export const EventBus = new Vue();
